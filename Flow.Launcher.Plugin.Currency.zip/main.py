# -*- coding: utf-8 -*-


from plugin import Main

if __name__ == "__main__":
    Main()